﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour


{
    public GameObject[] starObjs;
    public int maxRow = 12;
    public int maxColumn = 10;
    public GameObject starGroup;
    public List<Star> StarList;
    public List<Star> ClickedStarList;
    public static GameManager gameManager_Instance;
    public Text currentScoreText;
    public float currentScore = 0f;
    public Text currentTotalScoreText;
    public float currentTotalScore = 0f;
    public Text HundleText;
    public int HurdleIndex = 1;
    public Text targetScoreText;
    public float targetScore = 0f;
    public int judgeSwitch = 0;
    public Button replay;

    void Start()
    {
        gameManager_Instance = this;
        GameStart(1);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void GameStart(int hurdle)
    {
        replay.gameObject.SetActive(false);
        HurdleIndex = hurdle;
        currentScore = 0;
        //currentTotalScore = 0;
        CreateStarList();
        SetHundleTargetScore(HurdleIndex);

        judgeSwitch = 0;
    }

    void CreateStarList()
    {
        //Instantiate();
        //row * column;
        for (int r=0; r< maxRow; r++)
        {
            for (int c=0; c< maxColumn; c++)
            {
            int index = Random.Range(0, 5);
            var obj = Instantiate(starObjs[index], starGroup.transform);
                Vector3 pos = new Vector3(48 * c, 48 * r, 0);
                obj.transform.localPosition = pos;

                var star = obj.GetComponent<Star>();
                star.Row = r;
                star.Column = c;
                StarList.Add(star);
            }
        }
    }
    public void FindTheSameStar(Star currentStar)
    {
        int row = currentStar.Row;
        int column = currentStar.Column;
        if (row < maxRow)
        {
            foreach (var item in StarList)
            {
                if (item.Row == row + 1 && item.Column == column)
                {
                    if (item.starColor == currentStar.starColor)
                    {
                        if (!ClickedStarList.Contains(item))
                        {
                            ClickedStarList.Add(item);
                            FindTheSameStar(item);
                        }
                    }
                }
            }
        }

        if (row >0)
        {
            foreach (var item in StarList)
            {
                if (item.Row == row - 1 && item.Column == column)
                {
                    if (item.starColor == currentStar.starColor)
                    {
                        if (!ClickedStarList.Contains(item))
                        {
                            ClickedStarList.Add(item);
                            FindTheSameStar(item);
                        }
                    }
                }
            }
        }

        if (column >0)
        {
            foreach (var item in StarList)
            {
                if (item.Row == row && item.Column == column-1)
                {
                    if (item.starColor == currentStar.starColor)
                    {
                        if (!ClickedStarList.Contains(item))
                        {
                            ClickedStarList.Add(item);
                            FindTheSameStar(item);
                        }
                    }
                }
            }
        }

        if (column <maxColumn)
        {
            foreach (var item in StarList)
            {
                if (item.Row == row && item.Column == column + 1)
                {
                    if (item.starColor == currentStar.starColor)
                    {
                        if (!ClickedStarList.Contains(item))
                        {
                            ClickedStarList.Add(item);
                            FindTheSameStar(item);
                        }
                    }
                }
            }
        }
    }

    public void ClearClickedStarList()
    {
        if(ClickedStarList.Count>=2)
        {
            foreach (var item in ClickedStarList)
            {
                item.DestroyStar();
                StarList.Remove(item);
            }
            foreach (var restStar in StarList)
            {
                int moveCount = 0;
                foreach (var clickedStar in ClickedStarList)
                {
                    if (restStar.Column == clickedStar.Column && restStar.Row > clickedStar.Row)
                    {
                        moveCount++;
                    }
                }
                if(moveCount >0)
                {
                    restStar.moveDownCount = moveCount;
                    restStar.OpenMoveDown();
                }
                
            }
            for(int col=maxColumn-2;col>=0;col--)
            {
                bool IsEmpty = true;

                foreach (var restStar in StarList)
                {
                    if (restStar.Column == col)
                    {
                        IsEmpty = false;
                    }
                }
                if (IsEmpty)
                {
                    foreach (var restStar in StarList)
                    {
                        if(restStar.Column>col)
                        {
                           restStar.moveLeftCount++;
                        }
                    }
                }
            }
            foreach (var restStar in StarList)
            {
                if(restStar.moveLeftCount>=1)
                {
                    restStar.OpenMoveLeft();
                }
            }
        }
        CalculateScore(ClickedStarList.Count);

        ClickedStarList.Clear();
        JudgeHurdleOver();
        
    }

    public void JudgeHurdleOver()
    {
        bool isOver = true;
        foreach (var restStar in StarList)
        {
            FindTheSameStar(restStar);
            if (ClickedStarList.Count>0)
            {
                isOver = false;
            }
        }
        ClickedStarList.Clear();

        if (isOver)
        {
            if (judgeSwitch == 0)
            {
                judgeSwitch = 1;
                Debug.Log("Over");
                RestStarRewardScore(StarList.Count);
                foreach(var restStar in StarList)
                {
                    restStar.DestroyStar();
                }
                StarList.Clear();

                if (currentTotalScore >= targetScore)
                {
                    int index = HurdleIndex + 1;
                    GameStart(index);
                }
                else
                {
                    GameOver();
                }
            }
        }
    }

    void CalculateScore(int destroyStarCount)
    {
        if (destroyStarCount>=2)
        {
            float tempScore = 0f;
            for (int i = 0; i < destroyStarCount; i++)
            {
                tempScore += i * 10 + 5;
            }
            currentScore = tempScore;
            currentScoreText.text = currentScore.ToString();
            currentTotalScore += currentScore;
            currentTotalScoreText.text = currentTotalScore.ToString();
        }
    }

    void RestStarRewardScore(int restStarCount)
    {
        float rewardScore = 0;
        if (restStarCount < 10)
        {
            rewardScore = 2000 - restStarCount * 100;
            currentTotalScore += rewardScore;
            currentTotalScoreText.text = currentTotalScore.ToString();
        }
    }

    void SetHundleTargetScore(int hurdleIndex)
    {
        HundleText.text = "关卡："+ hurdleIndex.ToString();

        if (hurdleIndex==1)
        {
            targetScore = 1000;
        }
        else if (hurdleIndex > 1)

        {
            targetScore = 1000;
            for(int i=1; i<hurdleIndex; i++)
            {
                targetScore += 2000 + (i-1) * 100;
            }
        }
        targetScoreText.text = "目标:"+ targetScore.ToString();
    }
    void GameOver()
    {
        replay.gameObject.SetActive(true);
    }

    public void ReplayGame()
    {
        SceneManager.LoadScene("PopStar");
    }
}
