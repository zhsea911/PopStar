﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum StarColor
{
    Blue = 0,
    Green = 1,
    Yellow = 2,
    Purple = 3,
    Red = 4,
}
public class Star : MonoBehaviour
{
    public int Row = 0;
    public int Column = 0;
    public StarColor starColor = StarColor.Blue;
    public int moveDownCount = 0;
    private bool IsmoveDown = false;
    public int moveLeftCount = 0;
    private bool IsmoveLeft = false;
    public float speed = -5f;
    private int targetRow = 0;
    private int targetColumn = 0;


    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (IsmoveDown)
        {
           
            Row = targetRow;
            Vector3 downVector = new Vector3(0, 1, 0);
            if (this.transform .localPosition.y>targetRow *48f)
            {
                this.transform.Translate(downVector * speed);
            }
            else
            { 
                this.transform.localPosition = new Vector3(this.transform.localPosition.x, targetRow * 48f, this.transform.localPosition.z);
                
                IsmoveDown = false;
                moveDownCount = 0;
            }
            
        }

        if (IsmoveLeft)
        {
            
            Column = targetColumn;
            Vector3 leftVector = new Vector3(1, 0, 0);
            if (this.transform.localPosition.x > targetColumn * 48f)
            {
                this.transform.Translate(leftVector * speed);
            }
            else
            {
                this.transform.localPosition = new Vector3(targetColumn * 48f, this.transform.localPosition.y, this.transform.localPosition.z);
                
                IsmoveLeft = false;
                moveLeftCount = 0;
            }

        }

    }
    public void OnClick_Star()
    {
        //Debug.Log(starColor.ToString());
        GameManager.gameManager_Instance.FindTheSameStar(this);
        GameManager.gameManager_Instance.ClearClickedStarList();
    }

    public void DestroyStar()
    {
        Destroy(this.gameObject);
    }

    public void OpenMoveDown()
    {
        IsmoveDown = true;
        targetRow = Row - moveDownCount;
    }
    public void OpenMoveLeft()
    {
        IsmoveLeft = true;
        targetColumn = Column - moveLeftCount;
    }
    public void MoveDown()
    {

    }

}
